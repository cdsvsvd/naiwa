import turtle
import math
import time

FRAME_DELAY = 0.008
UPDATE_EVERY = 4

LINE_WIDTH = 2.8
INNER_EYE_WIDTH = 3.8

IMG_W = 1078
IMG_H = 898

screen = turtle.Screen()
screen.setup(width=1180, height=920)
screen.title("Turtle 精细轮廓绘画")
screen.bgcolor("white")
screen.tracer(0, 0)

pen = turtle.Turtle()
pen.hideturtle()
pen.speed(0)
pen.pencolor("black")
pen.pensize(LINE_WIDTH)

axis_pen = turtle.Turtle()
axis_pen.hideturtle()
axis_pen.speed(0)

def point(x, y):
    return (
        x - IMG_W / 2,
        IMG_H / 2 - y
    )


def move_to(p, pos):
    p.penup()
    p.goto(point(*pos))


def line_to(p, pos):
    p.pendown()
    p.goto(point(*pos))


def draw_line(p, start, end):
    move_to(p, start)
    line_to(p, end)
    p.penup()

def cubic_bezier(p0, p1, p2, p3, count=150):
    pts = []

    for i in range(count + 1):
        t = i / count
        u = 1 - t

        x = (
            u ** 3 * p0[0]
            + 3 * u ** 2 * t * p1[0]
            + 3 * u * t ** 2 * p2[0]
            + t ** 3 * p3[0]
        )

        y = (
            u ** 3 * p0[1]
            + 3 * u ** 2 * t * p1[1]
            + 3 * u * t ** 2 * p2[1]
            + t ** 3 * p3[1]
        )

        pts.append((x, y))

    return pts

def make_path(start, segments):
    result = [start]
    current = start

    for c1, c2, end in segments:
        part = cubic_bezier(
            current, c1, c2, end
        )
        result.extend(part[1:])
        current = end

    return result

def ellipse(cx, cy, rx, ry, count=360):
    pts = []

    for i in range(count + 1):
        t = 2 * math.pi * i / count

        x = cx + rx * math.cos(t)
        y = cy + ry * math.sin(t)

        pts.append((x, y))

    return pts


def ellipse_arc_between(
    start,
    end,
    angle_start,
    angle_end,
    count=240
):

    a = angle_start
    b = angle_end

    cos_diff = math.cos(b) - math.cos(a)
    sin_diff = math.sin(b) - math.sin(a)

    if abs(cos_diff) < 1e-10:
        raise ValueError("椭圆角度的余弦差不能为0")

    if abs(sin_diff) < 1e-10:
        raise ValueError("椭圆角度的正弦差不能为0")

    rx = (end[0] - start[0]) / cos_diff
    ry = (end[1] - start[1]) / sin_diff

    if rx <= 0 or ry <= 0:
        raise ValueError("椭圆半径必须为正")

    cx = start[0] - rx * math.cos(a)
    cy = start[1] - ry * math.sin(a)

    pts = []

    for i in range(count + 1):
        t = a + (b - a) * i / count

        x = cx + rx * math.cos(t)
        y = cy + ry * math.sin(t)

        pts.append((x, y))

    # 严格锁定端点
    pts[0] = start
    pts[-1] = end

    return pts

def animate_path(points, width=LINE_WIDTH):
    if len(points) < 2:
        return

    pen.pensize(width)
    move_to(pen, points[0])
    pen.pendown()

    for i, p in enumerate(points[1:], 1):
        pen.goto(point(*p))

        if i % UPDATE_EVERY == 0:
            screen.update()
            time.sleep(FRAME_DELAY)

    pen.goto(point(*points[-1]))
    pen.penup()

    screen.update()
    time.sleep(0.10)

def dashed_line(start, end, dash=4, gap=5):
    x1, y1 = start
    x2, y2 = end

    length = math.hypot(x2 - x1, y2 - y1)

    if length == 0:
        return

    ux = (x2 - x1) / length
    uy = (y2 - y1) / length

    distance = 0

    while distance < length:
        stop = min(distance + dash, length)

        a = (
            x1 + ux * distance,
            y1 + uy * distance
        )

        b = (
            x1 + ux * stop,
            y1 + uy * stop
        )

        draw_line(axis_pen, a, b)

        distance += dash + gap


def draw_arrow(tip, left, right):
    axis_pen.fillcolor("black")

    move_to(axis_pen, tip)
    axis_pen.begin_fill()

    line_to(axis_pen, left)
    line_to(axis_pen, right)
    line_to(axis_pen, tip)

    axis_pen.end_fill()
    axis_pen.penup()


def write_text(x, y, txt, size=14, align="center"):
    move_to(axis_pen, (x, y))

    axis_pen.write(
        str(txt),
        align=align,
        font=("Times New Roman", size, "normal")
    )


def draw_coordinate_system():
    axis_pen.pencolor("#DDDDDD")
    axis_pen.pensize(0.8)

    # 水平网格
    for y in [
        61, 121, 182, 242, 302,
        363, 423, 484, 543
    ]:
        dashed_line(
            (87, y),
            (1010, y)
        )

    # 垂直网格
    for x in [
        171, 256, 341, 427, 512,
        598, 683, 769, 855, 941
    ]:
        dashed_line(
            (x, 40),
            (x, 543)
        )

    axis_pen.pencolor("black")
    axis_pen.pensize(1.6)

    # X轴
    draw_line(
        axis_pen,
        (87, 543),
        (1008, 543)
    )

    draw_arrow(
        (1012, 543),
        (1000, 538),
        (1000, 548)
    )

    # Y轴
    draw_line(
        axis_pen,
        (87, 543),
        (87, 37)
    )

    draw_arrow(
        (87, 32),
        (82, 44),
        (92, 44)
    )

    # X轴刻度
    for number in range(-4, 7):
        x = 427 + number * 85.5
        write_text(x, 573, number, 13)

    # Y轴刻度
    for number in range(-4, 5):
        y = 302 - number * 60.25
        write_text(
            69, y + 5,
            number, 13, "right"
        )

    write_text(1028, 551, "x", 18)
    write_text(87, 19, "y", 18)

    screen.update()

outer = make_path(
    (302, 543),
    [
        # 左下轮廓
        (
            (337, 502),
            (371, 446),
            (370, 382)
        ),

        # 脸颊
        (
            (369, 337),
            (344, 301),
            (312, 282)
        ),

        # 鼻尖向上
        (
            (324, 260),
            (329, 229),
            (333, 208)
        ),

        # 额头至头顶
        (
            (354, 126),
            (430, 98),
            (500, 101)
        ),

        # 头顶至右侧
        (
            (580, 101),
            (648, 142),
            (684, 255)
        ),

        # 身体右侧上半段
        (
            (708, 319),
            (758, 376),
            (787, 425)
        ),

        # 身体右侧下半段
        (
            (816, 469),
            (839, 513),
            (851, 543)
        )
    ]
)

def head_at_y(target_y):

    for i in range(len(outer) - 1):
        x1, y1 = outer[i]
        x2, y2 = outer[i + 1]

        # 只考虑左侧头部
        if x1 >= 400 or x2 >= 400:
            continue

        if min(y1, y2) <= target_y <= max(y1, y2):

            if abs(y2 - y1) < 1e-12:
                continue

            ratio = (target_y - y1) / (y2 - y1)

            x = x1 + ratio * (x2 - x1)

            return (x, target_y)

    raise ValueError(
        f"未找到头部在 y={target_y} 的交点"
    )

ear_top = head_at_y(181)
ear_bottom = head_at_y(241)
ear_outer = ellipse_arc_between(
    start=ear_top,
    end=ear_bottom,
    angle_start=-1.20,
    angle_end=-4.25,
    count=260
)

inner_top = head_at_y(195)

outer_start_angle = -1.20
outer_end_angle = -4.25
merge_angle = -4.05

merge_ratio = (
    (merge_angle - outer_start_angle)
    / (outer_end_angle - outer_start_angle)
)

merge_index = round(
    merge_ratio * (len(ear_outer) - 1)
)

inner_bottom = ear_outer[merge_index]

ear_inner = ellipse_arc_between(
    start=inner_top,
    end=inner_bottom,
    angle_start=-1.15,
    angle_end=-4.10,
    count=240
)

# 外眼圈：正常线宽
eye_outer = ellipse(
    cx=451,
    cy=194,
    rx=49,
    ry=47,
    count=360
)

# 内眼圈
eye_inner = ellipse(
    cx=468,
    cy=195,
    rx=23,
    ry=24,
    count=360
)

mouth = [
    (320, 289),
    (417, 289)
]

def draw_character():

    # 坐标系
    draw_coordinate_system()
    time.sleep(0.35)

    # 左侧外弧
    animate_path(
        ear_outer,
        width=LINE_WIDTH
    )

    # 左侧内部椭圆弧
    animate_path(
        ear_inner,
        width=LINE_WIDTH
    )

    # 主体轮廓
    animate_path(
        outer,
        width=LINE_WIDTH
    )

    # 嘴巴
    animate_path(
        mouth,
        width=LINE_WIDTH
    )

    # 右侧外眼圈
    animate_path(
        eye_outer,
        width=LINE_WIDTH
    )

    # 右侧内眼圈
    animate_path(
        eye_inner,
        width=INNER_EYE_WIDTH
    )

    screen.update()

    print("绘制完成！")

if __name__ == "__main__":
    draw_character()
    screen.mainloop()
